using UnityEngine;
using UnityEngine.UI;

public class HealthBar : MonoBehaviour
{
    [SerializeField] private Slider slider;

    private void Start()
    {
        if (slider == null)
            slider = GetComponent<Slider>();

        if (PlayerController.Instance != null)
        {
            PlayerController.Instance.onHealthChangedCallback += UpdateHealthBar;
            UpdateHealthBar();
        }
    }

    private void OnEnable()
    {
        if (PlayerController.Instance != null)
        {
            PlayerController.Instance.onHealthChangedCallback += UpdateHealthBar;
            UpdateHealthBar();
        }
    }

    private void OnDisable()
    {
        if (PlayerController.Instance != null)
        {
            PlayerController.Instance.onHealthChangedCallback -= UpdateHealthBar;
        }
    }

    private void UpdateHealthBar()
    {
        if (PlayerController.Instance != null)
        {
            slider.maxValue = PlayerController.Instance.maxHealth;
            slider.value = PlayerController.Instance.Health;
        }
    }
}
