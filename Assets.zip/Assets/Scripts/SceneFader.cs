using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class SceneFader : MonoBehaviour
{
    [SerializeField] private float fadeTime;
    [SerializeField] private Image fadeOutUIImage;
    public enum FadeDirection
    {
        In,
        Out
    }
    private void Awake()
    {
        // fallback if not assigned manually
        if (fadeOutUIImage == null)
            fadeOutUIImage = GetComponent<Image>();
    }
    // Start is called before the first frame update
    void Start()
    {
        fadeOutUIImage = GetComponent<Image>();
    }
    // Update is called once per frame
    void Update()
    {

    }
    public IEnumerator Fade(FadeDirection _fadeDirection)
    {
        if (fadeOutUIImage == null)
        {
            Debug.LogError("[SceneFader] fadeOutUIImage is NULL � please assign it!");
            yield break;
        }

        float _alpha = _fadeDirection == FadeDirection.Out ? 1 : 0;
        float _fadeEndValue = _fadeDirection == FadeDirection.Out ? 0 : 1;

        fadeOutUIImage.enabled = true;

        while ((_fadeDirection == FadeDirection.Out && _alpha >= _fadeEndValue)
            || (_fadeDirection == FadeDirection.In && _alpha <= _fadeEndValue))
        {
            SetColorImage(ref _alpha, _fadeDirection);
            yield return null;
        }

        if (_fadeDirection == FadeDirection.Out)
            fadeOutUIImage.enabled = false;
    }

    void SetColorImage(ref float _alpha, FadeDirection _fadeDirection)
    {
        fadeOutUIImage.color = new Color(
            fadeOutUIImage.color.r,
            fadeOutUIImage.color.g,
            fadeOutUIImage.color.b,
            _alpha
        );

        _alpha += Time.deltaTime * (1 / fadeTime) * (_fadeDirection == FadeDirection.Out ? -1 : 1);
    }
public IEnumerator FadeAndLoadScene(FadeDirection _fadeDirection, string _sceneToLoad)
    {
        fadeOutUIImage.enabled = true;

        yield return Fade(_fadeDirection);

        SceneManager.LoadScene(_sceneToLoad);
    }
}
