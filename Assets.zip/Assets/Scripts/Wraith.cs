﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Wraith : Enemy
{
    [SerializeField] private float ledgeCheckX;
    [SerializeField] private float ledgeCheckY;
    [SerializeField] private float chargeSpeedMultiplier;
    [SerializeField] private float chargeDuration;
    [SerializeField] private float jumpForce;
    [SerializeField] private LayerMask whatIsGround;
    [SerializeField] private Sprite originalSprite;
    [SerializeField] private Sprite angryWraithSprite;

    [Header("Flip Behavior")]
    [SerializeField] private float flipWaitTime = 0.5f;

    private SpriteRenderer spriteRenderer;
    private float timer;
    private float flipTimer;
    private bool isFlipping = false;

    private Transform playerTransform;
    private Vector2 chargeDirection;

    protected override void Start()
    {
        base.Start();
        spriteRenderer = GetComponent<SpriteRenderer>();
        ChangeState(EnemyStates.Wraith_Idle);
        rb.gravityScale = 12f;
    }

    protected override void UpdateEnemyStates()
    {
        if (health <= 0)
        {
            Destroy(gameObject, 0.05f);
        }

        Vector3 _ledgeCheckStart = transform.localScale.x > 0 ? new Vector3(ledgeCheckX, 0) : new Vector3(-ledgeCheckX, 0);
        Vector2 _wallCheckDir = transform.localScale.x > 0 ? transform.right : -transform.right;

        switch (GetCurrentEnemyState)
        {
            case EnemyStates.Wraith_Idle:
                bool noGroundAhead = !Physics2D.Raycast(transform.position + _ledgeCheckStart, Vector2.down, ledgeCheckY, whatIsGround);
                bool hitWall = Physics2D.Raycast(transform.position, _wallCheckDir, ledgeCheckX, whatIsGround);

                Debug.DrawRay(transform.position + _ledgeCheckStart, Vector2.down * ledgeCheckY, Color.yellow);
                Debug.DrawRay(transform.position, _wallCheckDir * ledgeCheckX, Color.red);

                if (!isFlipping && (noGroundAhead || hitWall))
                {
                    isFlipping = true;
                    flipTimer = 0;
                }
                if (isFlipping)
                {
                    flipTimer += Time.deltaTime;
                    if (flipTimer >= flipWaitTime)
                    {
                        isFlipping = false;
                        flipTimer = 0;
                        transform.localScale = new Vector2(-transform.localScale.x, transform.localScale.y);
                    }
                }

                RaycastHit2D _hit = Physics2D.Raycast(transform.position + _ledgeCheckStart, _wallCheckDir, ledgeCheckX * 10, LayerMask.GetMask("Player"));
                Debug.DrawRay(transform.position + _ledgeCheckStart, _wallCheckDir * (ledgeCheckX * 10), Color.green);
                if (_hit.collider != null && _hit.collider.CompareTag("Player"))
                {
                    playerTransform = _hit.collider.transform;
                    ChangeState(EnemyStates.Wraith_Surprised);
                }

                rb.linearVelocity = new Vector2(transform.localScale.x > 0 ? speed : -speed, rb.linearVelocity.y);
                break;

            case EnemyStates.Wraith_Surprised:
                rb.linearVelocity = new Vector2(0, jumpForce);

                if (playerTransform != null)
                {
                    chargeDirection = (playerTransform.position - transform.position).normalized;
                    if (chargeDirection.x < 0 && transform.localScale.x > 0)
                        transform.localScale = new Vector2(-transform.localScale.x, transform.localScale.y);
                    else if (chargeDirection.x > 0 && transform.localScale.x < 0)
                        transform.localScale = new Vector2(-transform.localScale.x, transform.localScale.y);
                }

                ChangeState(EnemyStates.Wraith_Mad);
                break;

            case EnemyStates.Wraith_Mad:
                spriteRenderer.sprite = angryWraithSprite;
                timer += Time.deltaTime;

                if (timer < chargeDuration)
                {
                    rb.linearVelocity = new Vector2(
                        chargeDirection.x * speed * chargeSpeedMultiplier,
                        rb.linearVelocity.y
                    );
                }
                else
                {
                    timer = 0;
                    spriteRenderer.sprite = originalSprite;
                    ChangeState(EnemyStates.Wraith_Idle);
                }
                break;
        }
    }
}
